import App from './App'
import Home from './Home/index'
import NotFound from './NotFound'

export {
  App,
  Home,
  NotFound
}
