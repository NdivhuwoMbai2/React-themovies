import FilterList from "./FilterList";
import Product from './Movie'
import ProductList from './MovieList'
import Details from './Details'

export { Product, ProductList, Details, FilterList };
